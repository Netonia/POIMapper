﻿let a = 22;
(function () {
    console.log("functia testare");
    console.log(a);
})(a)